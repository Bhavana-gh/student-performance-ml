
# Student Performance Prediction using Machine Learning

## Problem Statement
Predict student final scores based on study hours, attendance, and previous exam scores.

## Technologies Used
- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib

## Steps
1. Load and preprocess data
2. Train regression model
3. Evaluate predictions

## Result
The model predicts student performance with good accuracy using linear regression.
